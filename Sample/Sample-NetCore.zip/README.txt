In order to run .NET Core tests, you need to copy the following files PER EACH test file you want to run:

Compile the project (e.g. dotnet build) and from the built directory, copy:
- tests.deps.json -> rename to myTestFile.deps.json
  Remove the dll from 'runtime' or copy also the 'tests.dll' that will be compiled
- tests.runtimeconfig.json -> rename to myTestFile.runtimeconfig.json
- tests.runtimeconfig.dev.json -> rename to myTestFile.runtimeconfig.dev.json
- Core.TestAdapter.dll (from the packages directory)

Alternatively you may try to modify the runtimeconfig.json to point to the deps.json file and add the path
of the Core.TestAdapter.dll, but you will still need to have a runtimeconfig.json file present per each test file.